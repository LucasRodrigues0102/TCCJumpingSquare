function check_collision(_move_x, _move_y) 
{
    var _collision = instance_place(
        x + _move_x,
        y + _move_y,
        obj_collision
    );

    if (_collision != noone)
    {
        if (_collision.object_index == obj_locked_door && has_key)
        {
            has_key = false;

            with (_collision)
            {
                instance_destroy();
            }

            audio_play_sound(snd_health_pickup_01, 0, 0);

            return false;
        }

        return true;
    }

    return false;
}