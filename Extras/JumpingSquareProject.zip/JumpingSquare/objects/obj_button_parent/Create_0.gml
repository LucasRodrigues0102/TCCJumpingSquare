// text: The text that will be displayed on this button
text = "Button";
// text_color: The color of the text on this button
text_color = c_white;

if (!variable_global_exists("menu_atual"))
{
    global.menu_atual = "main";
}

menu_tipo = "main";