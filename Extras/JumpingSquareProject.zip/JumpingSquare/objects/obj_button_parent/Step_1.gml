if (menu_tipo != global.menu_atual)
{
    image_index = 0;
    exit;
}

var _mouse_gui_x = device_mouse_x_to_gui(0);
var _mouse_gui_y = device_mouse_y_to_gui(0);

if (collision_point(_mouse_gui_x, _mouse_gui_y, object_index, false, false) == id)
{
    image_index = 1;

    if (mouse_check_button_released(mb_left) && !global.button_click_consumed)
    {
        global.button_click_consumed = true;

        image_index = 0;

        event_user(0);

        audio_play_sound(snd_button_press_01, 0, 0);
    }
}
else
{
    image_index = 0;
}