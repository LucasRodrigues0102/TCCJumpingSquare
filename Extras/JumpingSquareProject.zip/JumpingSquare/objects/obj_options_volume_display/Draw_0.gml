if (global.menu_atual != "options")
{
    exit;
}

var volume_percent = round(global.volume * 100);

draw_set_font(ft_button);
draw_set_colour(c_white);
draw_set_halign(fa_center);
draw_set_valign(fa_middle);

draw_text(x, y, "VOLUME: " + string(volume_percent) + "%");

draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_colour(c_white);