if (global.options_sequence != -1)
{
    layer_sequence_destroy(global.options_sequence);
    global.options_sequence = -1;
}

with (obj_options_background)
{
    visible = false;
}

global.menu_atual = "main";

if (global.menu_origem == "main")
{
    layer_set_visible(layer_get_id("Sequence"), true);
}