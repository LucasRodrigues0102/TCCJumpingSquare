if (!instance_exists(obj_player))
{
	exit;
}

if (!obj_player.has_key)
{
	exit;
}

draw_self();