if (global.menu_atual != "options")
{
    exit;
}

draw_self();