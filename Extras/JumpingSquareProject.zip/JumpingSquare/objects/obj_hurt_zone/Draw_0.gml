var _steps = 20;
var _height = bbox_bottom - bbox_top;
var _step_height = _height / _steps;

draw_set_color(c_black);

for (var _i = 0; _i < _steps; _i++)
{
	var _t = _i / _steps; // vai de 0 no topo até quase 1 no fundo

	// Elevando ao quadrado faz a transição começar bem sutil no topo
	// e acelerar conforme desce, ao invés de crescer de forma linear
	draw_set_alpha(_t * _t * 0.8);

	draw_rectangle(bbox_left, bbox_top + _i * _step_height, bbox_right, bbox_top + (_i + 1) * _step_height, false);
}

draw_set_alpha(1);