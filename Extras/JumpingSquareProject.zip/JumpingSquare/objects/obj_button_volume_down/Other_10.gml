if (!variable_global_exists("volume"))
{
    global.volume = 1;
}

global.volume = clamp(global.volume - 0.1, 0, 1);
audio_group_set_gain(audiogroup_default, global.volume, 0);