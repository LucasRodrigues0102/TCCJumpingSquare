if (room == rm_menu)
{
    global.menu_origem = "main";
}
else
{
    global.menu_origem = "pause";
}

global.menu_atual = "options";

if (global.menu_origem == "main")
{
    layer_set_visible(layer_get_id("Sequence"), false);
}

global.options_sequence = layer_sequence_create(
    "Options_UI",
    0,
    0,
    seq_options_menu
);