// Impede problemas das vidas não reiniciarem caso alguém volte pro menu depois de perder vidas
global.lives = 3;


// This takes the player to the next room.
// In the Room Order, after the menu room, the next room is rm_level_1 (the first level).
room_goto_next();