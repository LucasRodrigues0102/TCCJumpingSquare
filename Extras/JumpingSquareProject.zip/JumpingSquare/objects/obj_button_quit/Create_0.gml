event_inherited();

menu_tipo = "main";

// Set the text for this button
text = "Quit";