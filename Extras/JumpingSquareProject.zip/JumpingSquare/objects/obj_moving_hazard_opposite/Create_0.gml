start_x = x;
move_range = 300;
move_speed_h = 4;
direction_h = -1;
pause_timer = 0;
pause_duration = 30;