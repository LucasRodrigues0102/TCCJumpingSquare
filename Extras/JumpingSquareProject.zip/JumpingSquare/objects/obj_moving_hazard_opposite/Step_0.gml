if (pause_timer > 0)
{
    pause_timer -= 1;
}
else
{
    x += move_speed_h * direction_h;

    if (x <= start_x - move_range)
    {
        x = start_x - move_range;
        direction_h = 1;
        pause_timer = pause_duration;
    }
    else if (x >= start_x)
    {
        x = start_x;
        direction_h = -1;
        pause_timer = pause_duration;
    }
}