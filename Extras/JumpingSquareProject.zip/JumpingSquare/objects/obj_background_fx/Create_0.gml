// Define a profundidade bem alta, pra garantir que esse objeto é desenhado primeiro,
// ficando atrás de tudo (plataformas, espinhos, jogador)
depth = 10000;

// Duas variáveis de matiz, uma pro topo do degradê e outra pro fundo,
// começando em pontos diferentes da roda de cores pra já ter contraste
hue_top = 0;
hue_bottom = 140;

// O quão rápido a cor muda por frame. Valores baixos deixam a transição bem suave
hue_speed = 0.15;