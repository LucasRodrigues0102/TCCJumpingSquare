hue_top += hue_speed;
hue_bottom += hue_speed;

if (hue_top >= 360) hue_top -= 360;
if (hue_bottom >= 360) hue_bottom -= 360;