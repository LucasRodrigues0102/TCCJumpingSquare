var _cam = view_camera[0];
var _vx = camera_get_view_x(_cam);
var _vy = camera_get_view_y(_cam);
var _vw = camera_get_view_width(_cam);
var _vh = camera_get_view_height(_cam);

var _col_top = make_colour_hsv(hue_top, 180, 220);
var _col_bottom = make_colour_hsv(hue_bottom, 180, 220);

draw_rectangle_color(_vx, _vy, _vx + _vw, _vy + _vh, _col_top, _col_top, _col_bottom, _col_bottom, false);