base_y = y;
float_timer = random(360);

spawn_x = x;
spawn_y = y;