event_inherited();

menu_tipo = "options";

// Set the text for this button
text = "Volume UP";