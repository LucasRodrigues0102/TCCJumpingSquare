event_inherited();

if (menu_tipo != global.menu_atual)
{
    exit;
}

var volume_percent = round(global.volume * 100);

draw_set_font(ft_button);
draw_set_colour(c_white);
draw_set_halign(fa_center);
draw_set_valign(fa_middle);
draw_set_alpha(image_alpha);

draw_text_transformed(
    x + 220,
    y - 200,
    "VOLUME: " + string(volume_percent) + "%",
    image_xscale * 3,
    image_yscale * 3,
    0
);

draw_set_alpha(1);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_colour(c_white);