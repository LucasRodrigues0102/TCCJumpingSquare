// This draws the end gate instance itself.
draw_self();