if (!instance_exists(obj_player))
{
	exit;
}

draw_self();

draw_set_font(ft_hud);
draw_set_color(c_white);
draw_text(x + 40, y - 25, "x" + string(global.lives));