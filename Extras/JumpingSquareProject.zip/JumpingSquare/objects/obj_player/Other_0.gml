if (bbox_top > room_height)
{
    player_lose_life();
}