has_key = true;

key_spawn_x = other.spawn_x;
key_spawn_y = other.spawn_y;

audio_play_sound(snd_health_pickup_01, 0, 0);

instance_destroy(other);