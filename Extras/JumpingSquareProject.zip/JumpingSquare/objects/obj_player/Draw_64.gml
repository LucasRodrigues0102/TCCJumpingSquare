if (transition_timer > 0)
{
	var _t;

	if (transition_timer > transition_half)
	{
		_t = (transition_duration - transition_timer) / transition_half;
	}
	else
	{
		_t = transition_timer / transition_half;
	}

	draw_set_alpha(_t);
	draw_set_color(c_black);
	draw_rectangle(0, 0, display_get_gui_width(), display_get_gui_height(), false);
	draw_set_alpha(1);
}