// Inherit the parent event
event_inherited();

// Checks for a jump input
if (jump_input)
{
	// Preforms a player jump
	player_jump();	
}

// Checks for a left input
if (left_input)
{
	// Preforms a player left movement
	player_left();	
}

// Checks for a right input
if (right_input)
{
	// Preforms a player right movement
	player_right();	
}

if (grounded && vel_x != 0)
{
	dust_timer -= 1;

	if (dust_timer <= 0)
	{
		dust_timer = 6;

		var _spawn_x = x - sign(vel_x) * 20;
		var _spawn_y = bbox_bottom - 2;

		var _frag = instance_create_layer(_spawn_x, _spawn_y, "Instances", obj_fragment);
		_frag.sprite_index = spr_fragment;
		_frag.vel_x = -sign(vel_x) * random_range(0.5, 1.2);
		_frag.vel_y = random_range(-3, -2);
		_frag.life = 20;
		_frag.life_max = 20;
	}
}