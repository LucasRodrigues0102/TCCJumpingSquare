global.lives += 1;

audio_play_sound(snd_health_pickup_01, 0, 0);

instance_destroy(other);