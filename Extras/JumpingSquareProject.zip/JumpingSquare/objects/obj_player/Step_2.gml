event_inherited();

if (!grounded)
{
	// Personagem está no ar, seja subindo ou caindo, sempre usa o mesmo sprite
	if (sprite_index != spr_player_jump)
	{
		sprite_index = spr_player_jump;
	}

	image_speed = 0;

	var _t = clamp(abs(vel_x) / move_speed, 0, 1);
	image_index = round(_t * (image_number - 1));
}
else
{
	switch (sprite_index)
	{
		case spr_player_walk:
			image_speed = 1;

			if (vel_x == 0)
			{
				sprite_index = spr_player_idle;
			}
			break;

		case spr_player_jump:
			// Acabou de aterrissar
			sprite_index = spr_player_idle;
			image_speed = 1;
			break;

		default:
			image_speed = 1;
			break;
	}
}