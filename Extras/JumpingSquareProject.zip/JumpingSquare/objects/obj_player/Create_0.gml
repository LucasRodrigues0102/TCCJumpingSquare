// This runs the Create event of the parent, ensuring the player gets all variables from the character parent.
event_inherited();

// Usado para a mecânica de chave
has_key = false;

// Criação do efeito de game over
transition_timer = 0;
transition_duration = 60;
transition_half = transition_duration / 2;

// Isso é pro efeito de partícula quando o player anda
dust_timer = 0

// This variable tells whether the player is currently in knockback (from being hit by an enemy). It will be true if it is, and false if not.
in_knockback = false;

// Flag for if a jump is detected
jump_input = false;

// Function to be called when a player jumps
player_jump = function()
{
	// This checks if the 'grounded' variable is true, meaning the player is standing on the ground, and can jump.
	if (grounded)
	{
		// This sets the Y velocity to negative jump_speed, making the player immediately jump upwards. It
		// will automatically be brought down by the gravity code in the parent's Begin Step event.
		vel_y = -jump_speed;

		// This changes the player's sprite to the jump sprite, and resets the frame to 0.
		sprite_index = spr_player_jump;
		image_index = 0;

		// This sets 'grounded' to false, so that any events after this know that the player is not supposed
		// to be on the ground anymore.
		grounded = false;

		// Substituido o efeito de pulo original por um de quadrados para a estética do jogo
		var _dirs = [-1, 1];

		for (var _i = 0; _i < array_length(_dirs); _i++)
		{
			var _dir = _dirs[_i];

			var _frag = instance_create_layer(x + _dir * 24, bbox_bottom - 2, "Instances", obj_fragment);
			_frag.sprite_index = spr_fragment;
			_frag.vel_x = _dir * random_range(1, 2);
			_frag.vel_y = random_range(-3, -2);
			_frag.life = 20;
			_frag.life_max = 20;
		}
	
		// Play the jump sound with a random pitch
		var _sound = audio_play_sound(snd_jump, 0, 0);
		audio_sound_pitch(_sound, random_range(0.8, 1));
	}
	
	// Sets jump flag back to false
	jump_input = false;
}

// Flag for if a left input is detected
left_input = false;

// Function to be called when a player goes left
player_left = function()
{
	// This checks if the player is currently in knockback, after being hit by an enemy.
	if (in_knockback)
	{
		// In that case we return
		return;
	}

	// Set the X velocity to negative move_speed.
	// This makes the character move left.
	vel_x = -move_speed;


	// This checks if the player is on the ground, before changing the sprite to the walking sprite. This is
	// done to ensure that the walking sprite does not active while the player is in mid-air.
	if (grounded)
	{
		// Change the instance's sprite to the walking player sprite.
		sprite_index = spr_player_walk;
	}
	
	// Sets input flag back to false
	left_input = false;
}

// Flag for if a right input is detected
right_input = false;

// Function to be called when a player goes right
player_right = function()
{
	// This checks if the player is currently in knockback, after being hit by an enemy.
	if (in_knockback)
	{
		// In that case we return
		return;
	}

	// Set the X velocity to move_speed.
	// This makes the character move right.
	vel_x = move_speed;

	// This checks if the player is on the ground, before changing the sprite to the walking sprite. This is
	// done to ensure that the walking sprite does not active while the player is in mid-air.
	if (grounded)
	{
		// Change the instance's sprite to the walking player sprite.
		sprite_index = spr_player_walk;
	}
	
	// Sets input flag back to false
	right_input = false;
}

//Cria um efeito de morte para o boneco caso ele falhe
spawn_death_burst = function(_amount)
{
	for (var _i = 0; _i < _amount; _i++)
	{
		var _angle = random(360);
		var _speed = random_range(2, 5);

		var _frag = instance_create_layer(x, y, "Instances", obj_fragment);
		_frag.sprite_index = spr_fragment;
		_frag.vel_x = lengthdir_x(_speed, _angle);
		_frag.vel_y = lengthdir_y(_speed, _angle);
		_frag.life = 40;
		_frag.life_max = 40;
	}
}

// Usado para garantir que as vidas existem para a função abaixo mexer nelas
if (!variable_global_exists("lives"))
{
	global.lives = 3;
}

// Função chamada sempre que o jogador perde uma vida, seja por cair no vazio ou tocar num perigo
player_lose_life = function()
{
	// Se já está no meio de uma transição, ignora, evitando disparar de novo
	// enquanto ainda está tocando o perigo ou caindo fora da sala
	if (transition_timer > 0)
	{
		return;
	}

	spawn_death_burst(10);

	global.lives -= 1;

	transition_timer = transition_duration;
	
	visible = false;
	
	audio_play_sound(snd_life_lost_01, 0, 0);
}