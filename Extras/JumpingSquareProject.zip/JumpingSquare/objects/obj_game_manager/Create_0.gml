global.game_manager = id;

// This creates the HUD sequence, which shows all HUD elements (such as coins and hearts). It lasts throughout the level.
layer_sequence_create("Instances", 0, 0, seq_game_hud);

// paused: This will be true when the game is paused, and false when it's not
paused = false;
// pause_sequence: The ID of the Sequence element created for the pause menu, used to close it
// when the player hits Escape to resume
pause_sequence = -1;

// Estado dos menus
if (!variable_global_exists("menu_atual"))
{
    global.menu_atual = "main";
}

if (!variable_global_exists("menu_origem"))
{
    global.menu_origem = "main";
}

if (!variable_global_exists("options_sequence"))
{
    global.options_sequence = -1;
}

if (!variable_global_exists("volume"))
{
	global.volume = 1;
}

if (!variable_global_exists("button_click_consumed"))
{
    global.button_click_consumed = false;
}