if (!mouse_check_button(mb_left))
{
    global.button_click_consumed = false;
}