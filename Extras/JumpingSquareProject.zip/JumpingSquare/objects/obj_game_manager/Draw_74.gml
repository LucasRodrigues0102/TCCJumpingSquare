if (global.menu_atual == "options")
{
    draw_set_colour(make_color_rgb(54, 54, 54));
    draw_set_alpha(1);

    draw_rectangle(
        0,
        0,
        display_get_gui_width(),
        display_get_gui_height(),
        false
    );
}

else if (paused)
{
    draw_set_colour(c_black);
    draw_set_alpha(0.6);

    draw_rectangle(
        0,
        0,
        display_get_gui_width(),
        display_get_gui_height(),
        false
    );
}

// Restaura as configurações de desenho
draw_set_alpha(1);
draw_set_colour(c_white);