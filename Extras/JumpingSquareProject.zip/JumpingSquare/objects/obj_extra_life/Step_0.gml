float_timer += 2;

if (float_timer >= 360)
{
	float_timer -= 360;
}

y = base_y + sin(degtorad(float_timer)) * 4;