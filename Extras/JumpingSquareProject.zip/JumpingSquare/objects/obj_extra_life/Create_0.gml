base_y = y;
float_timer = random(360);