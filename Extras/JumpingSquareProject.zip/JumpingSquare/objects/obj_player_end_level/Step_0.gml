var _target_x = obj_end_gate.x;

var _foot_offset = bbox_bottom - y;
var _target_y = obj_end_gate.bbox_bottom - _foot_offset;

var _at_x = (x == _target_x);
var _at_y = (y == _target_y);

if (!_at_x || !_at_y)
{
	x += clamp(_target_x - x, -4, 4);
	y += clamp(_target_y - y, -4, 4);

	sprite_index = spr_player_walk;
	image_speed = 0.7;
}
else
{
	sprite_index = spr_player_idle;
	image_alpha += -0.02;
	image_speed = 1;

	if (image_alpha <= 0)
	{
		room_goto_next();
	}
}