x += vel_x;
y += vel_y;

if (use_gravity)
{
	vel_y += 0.5;
}

vel_x *= 0.95;

life -= 1;
image_alpha = life / life_max;

if (life <= 0)
{
	instance_destroy();
}