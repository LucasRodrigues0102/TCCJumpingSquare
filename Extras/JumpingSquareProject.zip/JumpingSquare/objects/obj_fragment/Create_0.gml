vel_x = 0;
vel_y = 0;
use_gravity = true;
life = 30;
life_max = life;